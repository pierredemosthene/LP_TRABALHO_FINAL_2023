# LP_Projeto_Final_Pierre

Trabalho final da disciplina de Linguagens de Programação UFFS (2023/2)

Feliz Natal Professor!
